const { query } = require('../helpers/db');

async function runAutoMigrations() {
  console.log('[Migration] Verifying database schema columns...');

  try {
    // 1. Candles table for persistent synthetic/historical market data
    await query(`
      CREATE TABLE IF NOT EXISTS candles (
        id VARCHAR(191) NOT NULL PRIMARY KEY,
        symbol VARCHAR(50) NOT NULL,
        timeframe INT NOT NULL,
        timestamp BIGINT NOT NULL,
        open DOUBLE NOT NULL,
        high DOUBLE NOT NULL,
        low DOUBLE NOT NULL,
        close DOUBLE NOT NULL,
        createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
        UNIQUE KEY idx_sym_tf_ts (symbol, timeframe, timestamp),
        KEY idx_sym_tf (symbol, timeframe),
        KEY idx_ts (timestamp)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    // Add createdAt column to settings table if missing
    try {
      const settingsCols = (await query('SHOW COLUMNS FROM settings')).map(c => c.Field);
      if (!settingsCols.includes('createdAt')) {
        await query('ALTER TABLE settings ADD COLUMN createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)');
      }
    } catch (e) {}

    // 2. Settings table defaults for separate Trade & Recharge commissions
    const defaultSettings = [
      { key: 'trade_bonus_a', val: '1' },
      { key: 'trade_bonus_b', val: '0.5' },
      { key: 'trade_bonus_c', val: '3' },
      { key: 'recharge_bonus_a', val: '5' },
      { key: 'recharge_bonus_b', val: '3' },
      { key: 'recharge_bonus_c', val: '2' },
      { key: 'ref_bonus_a', val: '5' },
      { key: 'ref_bonus_b', val: '3' },
      { key: 'ref_bonus_c', val: '2' },
    ];

    for (const s of defaultSettings) {
      await query(`
        INSERT INTO settings (id, \`key\`, value, updatedAt)
        VALUES (UUID(), ?, ?, NOW(3))
        ON DUPLICATE KEY UPDATE value = IF(value IS NULL OR value = '', VALUES(value), value), updatedAt = NOW(3)
      `, [s.key, s.val]);
    }

    // 3. Ensure commission_levels table has unique index on `level` for clean updates
    try {
      await query(`ALTER TABLE commission_levels ADD UNIQUE KEY idx_level (level)`);
    } catch (e) {}

    // 4. Update master_traders schema for copy trading rules
    try {
      const mtCols = (await query('SHOW COLUMNS FROM master_traders')).map(c => c.Field);
      if (!mtCols.includes('avatar')) await query('ALTER TABLE master_traders ADD COLUMN avatar VARCHAR(500) DEFAULT NULL');
      if (!mtCols.includes('minCopyAmount')) await query('ALTER TABLE master_traders ADD COLUMN minCopyAmount DOUBLE NOT NULL DEFAULT 50');
      if (!mtCols.includes('maxCopyAmount')) await query('ALTER TABLE master_traders ADD COLUMN maxCopyAmount DOUBLE NOT NULL DEFAULT 5000');
      if (!mtCols.includes('defaultCopyAmount')) await query('ALTER TABLE master_traders ADD COLUMN defaultCopyAmount DOUBLE NOT NULL DEFAULT 100');
      if (!mtCols.includes('durationDays')) await query('ALTER TABLE master_traders ADD COLUMN durationDays INT NOT NULL DEFAULT 7');
      if (!mtCols.includes('fee')) await query('ALTER TABLE master_traders ADD COLUMN fee DOUBLE NOT NULL DEFAULT 10');
    } catch (e) {}

    // 5. Update user_copy_trades schema for copy duration and claim protection
    try {
      const uctCols = (await query('SHOW COLUMNS FROM user_copy_trades')).map(c => c.Field);
      if (!uctCols.includes('durationDays')) await query('ALTER TABLE user_copy_trades ADD COLUMN durationDays INT NOT NULL DEFAULT 7');
      if (!uctCols.includes('startDate')) await query('ALTER TABLE user_copy_trades ADD COLUMN startDate DATETIME DEFAULT CURRENT_TIMESTAMP');
      if (!uctCols.includes('endDate')) await query('ALTER TABLE user_copy_trades ADD COLUMN endDate DATETIME DEFAULT NULL');
      if (!uctCols.includes('claimStatus')) await query("ALTER TABLE user_copy_trades ADD COLUMN claimStatus VARCHAR(50) NOT NULL DEFAULT 'unclaimed'");
      if (!uctCols.includes('profitClaimed')) await query('ALTER TABLE user_copy_trades ADD COLUMN profitClaimed DOUBLE NOT NULL DEFAULT 0');
    } catch (e) {}

    console.log('[Migration] Database schema columns verified & synchronized.');
  } catch (err) {
    console.error('[Migration Error]', err.message);
  }
}

if (require.main === module) {
  runAutoMigrations().then(() => process.exit(0));
}

module.exports = { runAutoMigrations };
