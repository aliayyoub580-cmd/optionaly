const express = require('express');
const dns = require('dns');
if (dns.setDefaultResultOrder) {
  dns.setDefaultResultOrder('ipv4first');
}
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const path = require('path');
const { port } = require('./config');
const errorHandler = require('./middleware/errorHandler');
const apiRoutes = require('./routes');

const app = express();

// Middleware
app.use(helmet({ contentSecurityPolicy: false }));

const allowedOrigins = [
  'https://optionaly.com',
  'https://www.optionaly.com',
  'http://localhost:5173',
  'http://localhost:3000',
  'http://localhost:5174'
];

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin) || origin.endsWith('.optionaly.com')) {
      return callback(null, true);
    }
    return callback(null, true); // Fallback allow all origins
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'Origin', 'Access-Control-Request-Headers', 'Access-Control-Request-Method'],
  optionsSuccessStatus: 200
};

app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
app.use(compression());
app.use(morgan('dev'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Mount main API routes router
app.use('/api', apiRoutes);

// Serve static uploads
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Debug DB — also auto-renames Prisma singular tables to plural on first run
app.get('/api/debug-db', async (req, res) => {
  try {
    const { query } = require('./helpers/db');

    // Auto-rename Prisma singular PascalCase tables to lowercase plural
    const RENAMES = {
      'Activity': 'activities',
      'Asset': 'assets',
      'BonusTier': 'bonus_tiers',
      'Bot': 'bots',
      'BotPerformance': 'bot_performances',
      'ChatMessage': 'chat_messages',
      'Commission': 'commissions',
      'CommissionLevel': 'commission_levels',
      'MasterTrader': 'master_traders',
      'News': 'news_items',
      'Notification': 'notifications',
      'PaymentSetting': 'payment_settings',
      'PeriodCounter': 'period_counters',
      'Referral': 'referrals',
      'ReferralDepositBonus': 'referral_deposit_bonuses',
      'Settings': 'settings',
      'Trade': 'trades',
      'TradeBonus': 'trade_bonuses',
      'Transaction': 'transactions',
      'User': 'users',
      'UserAchievement': 'user_achievements',
      'UserBot': 'user_bots',
      'UserCopyTrade': 'user_copy_trades',
    };

    const rawTables = await query('SHOW TABLES');
    const tableNames = rawTables.map(r => Object.values(r)[0]);

    const renamed = [];
    for (const [oldName, newName] of Object.entries(RENAMES)) {
      if (tableNames.includes(oldName) && !tableNames.includes(newName)) {
        await query(`RENAME TABLE \`${oldName}\` TO \`${newName}\``);
        renamed.push(`${oldName} → ${newName}`);
      }
    }

    const finalTables = (await query('SHOW TABLES')).map(r => Object.values(r)[0]);
    res.json({ success: true, renamed, tables: finalTables, driver: 'mysql2' });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Debug logs endpoint
app.get('/api/debug-logs', async (req, res) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const os = require('os');
    
    // Search directories relative to backend root
    const dirsToSearch = [
      path.join(__dirname, '..'), // backend/
      path.join(__dirname, '..', '..'), // root/
      path.join(os.homedir(), '.pm2', 'logs'), // PM2 logs
      path.join(os.homedir(), 'logs'), // Home logs
      path.join(os.homedir()), // Home root
    ];
    
    const logFiles = [];
    for (const dir of dirsToSearch) {
      try {
        if (!fs.existsSync(dir)) continue;
        const files = fs.readdirSync(dir);
        for (const file of files) {
          if (file.endsWith('.log') || file.includes('err') || file.includes('out') || file.includes('stderr') || file.includes('stdout')) {
            const fullPath = path.join(dir, file);
            const stats = fs.statSync(fullPath);
            logFiles.push({ name: file, path: fullPath, size: stats.size, mtime: stats.mtime });
          }
        }
      } catch (err) {}
    }
    
    const targetFile = req.query.file;
    if (targetFile) {
      const matched = logFiles.find(f => f.name === targetFile || f.path === targetFile);
      if (matched) {
        const content = fs.readFileSync(matched.path, 'utf8');
        return res.send(`<pre>${content}</pre>`);
      }
      return res.status(404).json({ error: 'Log file not found' });
    }
    
    return res.json({ logFiles });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// API Routes
app.use('/api', apiRoutes);

// Error handler
app.use(errorHandler);

// Global error capture
process.on('unhandledRejection', (reason) => {
  console.error('[UnhandledRejection]', reason?.message || reason, reason?.stack);
});

process.on('uncaughtException', (err) => {
  console.error('[UncaughtException] Critical unhandled error:', err?.message || err, err?.stack);
});

// Auto-run table rename on startup
async function autoMigrateTables() {
  try {
    const { query } = require('./helpers/db');
    const RENAMES = {
      'Activity': 'activities', 'Asset': 'assets', 'BonusTier': 'bonus_tiers',
      'Bot': 'bots', 'BotPerformance': 'bot_performances', 'ChatMessage': 'chat_messages',
      'Commission': 'commissions', 'CommissionLevel': 'commission_levels',
      'MasterTrader': 'master_traders', 'News': 'news_items', 'Notification': 'notifications',
      'PaymentSetting': 'payment_settings', 'PeriodCounter': 'period_counters',
      'Referral': 'referrals', 'ReferralDepositBonus': 'referral_deposit_bonuses',
      'Settings': 'settings', 'Trade': 'trades', 'TradeBonus': 'trade_bonuses',
      'Transaction': 'transactions', 'User': 'users', 'UserAchievement': 'user_achievements',
      'UserBot': 'user_bots', 'UserCopyTrade': 'user_copy_trades',
    };
    const rawTables = await query('SHOW TABLES');
    const tableNames = rawTables.map(r => Object.values(r)[0]);
    for (const [oldName, newName] of Object.entries(RENAMES)) {
      if (tableNames.includes(oldName) && !tableNames.includes(newName)) {
        await query(`RENAME TABLE \`${oldName}\` TO \`${newName}\``);
        console.log(`[DB] Renamed table: ${oldName} → ${newName}`);
      }
    }
    console.log('[DB] Table migration check complete.');

    // Ensure webhook_logs table exists
    await query(`
      CREATE TABLE IF NOT EXISTS webhook_logs (
        id VARCHAR(191) NOT NULL,
        payload TEXT NOT NULL,
        createdAt DATETIME NOT NULL,
        PRIMARY KEY (id)
      ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    `);
    console.log('[DB] Ensuring webhook_logs table exists.');

    // Ensure chat_messages table exists
    await query(`
      CREATE TABLE IF NOT EXISTS chat_messages (
        id VARCHAR(191) NOT NULL,
        chatRoomId VARCHAR(191) NOT NULL,
        senderRole VARCHAR(50) NOT NULL,
        senderName VARCHAR(191) NOT NULL,
        content TEXT NOT NULL,
        isRead TINYINT(1) NOT NULL DEFAULT 0,
        createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
        updatedAt DATETIME(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
        PRIMARY KEY (id),
        INDEX idx_chatRoomId (chatRoomId),
        INDEX idx_createdAt (createdAt),
        INDEX idx_isRead (isRead)
      ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    `);
    console.log('[DB] Ensuring chat_messages table exists.');

    // Ensure columns and data types on chat_messages if created previously without them
    try {
      const chatCols = await query('SHOW COLUMNS FROM chat_messages');
      const chatColNames = chatCols.map(c => c.Field);
      if (!chatColNames.includes('isRead')) {
        await query('ALTER TABLE chat_messages ADD COLUMN isRead TINYINT(1) NOT NULL DEFAULT 0');
        console.log('[DB] Added isRead column to chat_messages');
      }
      if (!chatColNames.includes('updatedAt')) {
        await query('ALTER TABLE chat_messages ADD COLUMN updatedAt DATETIME(3) NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)');
        console.log('[DB] Added updatedAt column to chat_messages');
      }
      if (!chatColNames.includes('attachmentUrl')) {
        await query('ALTER TABLE chat_messages ADD COLUMN attachmentUrl VARCHAR(255) DEFAULT NULL');
        console.log('[DB] Added attachmentUrl column to chat_messages');
      }
      if (!chatColNames.includes('attachmentType')) {
        await query('ALTER TABLE chat_messages ADD COLUMN attachmentType VARCHAR(50) DEFAULT NULL');
        console.log('[DB] Added attachmentType column to chat_messages');
      }
      if (!chatColNames.includes('attachmentName')) {
        await query('ALTER TABLE chat_messages ADD COLUMN attachmentName VARCHAR(255) DEFAULT NULL');
        console.log('[DB] Added attachmentName column to chat_messages');
      }
      if (!chatColNames.includes('attachmentSize')) {
        await query('ALTER TABLE chat_messages ADD COLUMN attachmentSize INT(11) DEFAULT NULL');
        console.log('[DB] Added attachmentSize column to chat_messages');
      }
      await query('ALTER TABLE chat_messages MODIFY COLUMN content TEXT NOT NULL');
    } catch (e) {
      console.error('[DB] Error verifying chat_messages columns:', e.message);
    }

    // Ensure news_items table columns exist
    try {
      const newsCols = await query('SHOW COLUMNS FROM news_items');
      const newsColNames = newsCols.map(c => c.Field);
      if (!newsColNames.includes('imageUrl')) {
        await query('ALTER TABLE news_items ADD COLUMN imageUrl VARCHAR(255) DEFAULT NULL');
        console.log('[DB] Added imageUrl column to news_items');
      }
      if (!newsColNames.includes('status')) {
        await query('ALTER TABLE news_items ADD COLUMN status VARCHAR(50) NOT NULL DEFAULT "published"');
        console.log('[DB] Added status column to news_items');
      }
    } catch (e) {
      console.error('[DB] Error verifying news_items columns:', e.message);
    }

    // Ensure referrals table exists
    await query(`
      CREATE TABLE IF NOT EXISTS referrals (
        id VARCHAR(191) NOT NULL,
        referrerId VARCHAR(191) NOT NULL,
        referredId VARCHAR(191) NOT NULL,
        level INT(11) NOT NULL DEFAULT 1,
        commissionEarned DOUBLE NOT NULL DEFAULT 0,
        status VARCHAR(191) NOT NULL DEFAULT 'active',
        createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
        updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
        PRIMARY KEY (id),
        INDEX idx_referrerId (referrerId),
        INDEX idx_referredId (referredId)
      ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    `);

    // Ensure updatedAt column exists on referrals if created previously without it
    const refCols = await query('SHOW COLUMNS FROM referrals');
    const refColNames = refCols.map(c => c.Field);
    if (!refColNames.includes('updatedAt')) {
      await query('ALTER TABLE referrals ADD COLUMN updatedAt DATETIME NULL');
      console.log('[DB] Added updatedAt column to referrals');
    }

    // Ensure referral_deposit_bonuses table and updatedAt column exist
    await query(`
      CREATE TABLE IF NOT EXISTS referral_deposit_bonuses (
        id VARCHAR(191) NOT NULL,
        referrerId VARCHAR(191) NOT NULL,
        depositorId VARCHAR(191) NOT NULL,
        depositorName VARCHAR(191) NOT NULL,
        depositAmount DOUBLE NOT NULL,
        bonusPercentage DOUBLE NOT NULL,
        bonusAmount DOUBLE NOT NULL,
        level INT(11) NOT NULL DEFAULT 1,
        status VARCHAR(191) NOT NULL DEFAULT 'pending',
        depositTxId VARCHAR(191) DEFAULT NULL,
        createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
        claimedAt DATETIME(3) DEFAULT NULL,
        updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
        PRIMARY KEY (id)
      ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    `);
    const rdbCols = await query('SHOW COLUMNS FROM referral_deposit_bonuses');
    const rdbColNames = rdbCols.map(c => c.Field);
    if (!rdbColNames.includes('updatedAt')) {
      await query('ALTER TABLE referral_deposit_bonuses ADD COLUMN updatedAt DATETIME NULL');
      console.log('[DB] Added updatedAt column to referral_deposit_bonuses');
    }

    // Ensure trade_bonuses table and updatedAt column exist
    await query(`
      CREATE TABLE IF NOT EXISTS trade_bonuses (
        id VARCHAR(191) NOT NULL,
        leaderId VARCHAR(191) NOT NULL,
        traderId VARCHAR(191) NOT NULL,
        traderName VARCHAR(191) NOT NULL,
        traderEmail VARCHAR(191) NOT NULL,
        assetSymbol VARCHAR(191) NOT NULL,
        tradeAmount DOUBLE NOT NULL,
        bonusPercentage DOUBLE NOT NULL,
        bonusAmount DOUBLE NOT NULL,
        tradeDirection VARCHAR(50) NOT NULL,
        tradeStatus VARCHAR(50) NOT NULL,
        status VARCHAR(191) NOT NULL DEFAULT 'pending',
        tradeId VARCHAR(191) DEFAULT NULL,
        createdAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
        claimedAt DATETIME(3) DEFAULT NULL,
        updatedAt DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
        PRIMARY KEY (id)
      ) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
    `);
    const tbCols = await query('SHOW COLUMNS FROM trade_bonuses');
    const tbColNames = tbCols.map(c => c.Field);
    if (!tbColNames.includes('updatedAt')) {
      await query('ALTER TABLE trade_bonuses ADD COLUMN updatedAt DATETIME NULL');
      console.log('[DB] Added updatedAt column to trade_bonuses');
    }

    try {
      const tbIndexes = await query('SHOW INDEX FROM trade_bonuses WHERE Key_name = "unique_leader_trade_pct"');
      if (tbIndexes.length === 0) {
        await query('ALTER TABLE trade_bonuses ADD CONSTRAINT unique_leader_trade_pct UNIQUE (leaderId, tradeId, bonusPercentage)');
        console.log('[DB] Added unique_leader_trade_pct constraint to trade_bonuses');
      }
    } catch (e) { }

    // Ensure userAccountType column exists on trades table
    try {
      const tradeCols = await query('SHOW COLUMNS FROM trades');
      const tradeColNames = tradeCols.map(c => c.Field);
      if (!tradeColNames.includes('userAccountType')) {
        await query("ALTER TABLE trades ADD COLUMN userAccountType VARCHAR(50) NOT NULL DEFAULT 'demo'");
        console.log('[DB] Added userAccountType column to trades');
      }
    } catch (e) { }

    // Ensure referrals referredId unique constraint
    try {
      const refIndexes = await query('SHOW INDEX FROM referrals WHERE Key_name = "unique_referredId"');
      if (refIndexes.length === 0) {
        await query('ALTER TABLE referrals ADD CONSTRAINT unique_referredId UNIQUE (referredId)');
        console.log('[DB] Added unique_referredId constraint to referrals');
      }
    } catch (e) {
      // Ignore if index already exists
    }

    // Ensure NOWPayments fields exist in transactions table
    const columns = await query('SHOW COLUMNS FROM transactions');
    const columnNames = columns.map(c => c.Field);
    if (!columnNames.includes('paymentId')) {
      await query('ALTER TABLE transactions ADD COLUMN paymentId VARCHAR(191) NULL');
      console.log('[DB] Added paymentId column to transactions');
    }
    if (!columnNames.includes('payAddress')) {
      await query('ALTER TABLE transactions ADD COLUMN payAddress VARCHAR(191) NULL');
      console.log('[DB] Added payAddress column to transactions');
    }
    if (!columnNames.includes('payAmount')) {
      await query('ALTER TABLE transactions ADD COLUMN payAmount DOUBLE NULL');
      console.log('[DB] Added payAmount column to transactions');
    }
    if (!columnNames.includes('payCurrency')) {
      await query('ALTER TABLE transactions ADD COLUMN payCurrency VARCHAR(50) NULL');
      console.log('[DB] Added payCurrency column to transactions');
    }
    if (!columnNames.includes('payStatus')) {
      await query('ALTER TABLE transactions ADD COLUMN payStatus VARCHAR(191) NULL');
      console.log('[DB] Added payStatus column to transactions');
    }
    if (!columnNames.includes('invoiceUrl')) {
      await query('ALTER TABLE transactions ADD COLUMN invoiceUrl VARCHAR(255) NULL');
      console.log('[DB] Added invoiceUrl column to transactions');
    }
    if (!columnNames.includes('gateway')) {
      await query("ALTER TABLE transactions ADD COLUMN gateway VARCHAR(50) NULL DEFAULT 'crypto'");
      console.log('[DB] Added gateway column to transactions');
    }
    if (!columnNames.includes('payType')) {
      await query('ALTER TABLE transactions ADD COLUMN payType VARCHAR(50) NULL');
      console.log('[DB] Added payType column to transactions');
    }

    // Ensure KYC and Referral columns exist in users table
    const userColumns = await query('SHOW COLUMNS FROM users');
    const userColumnNames = userColumns.map(c => c.Field);
    if (!userColumnNames.includes('kycStatus')) {
      await query("ALTER TABLE users ADD COLUMN kycStatus VARCHAR(50) NOT NULL DEFAULT 'none'");
      console.log('[DB] Added kycStatus column to users');
    }
    if (!userColumnNames.includes('kycDocument')) {
      await query('ALTER TABLE users ADD COLUMN kycDocument VARCHAR(255) NULL');
      console.log('[DB] Added kycDocument column to users');
    }
    if (!userColumnNames.includes('kycSubmittedAt')) {
      await query('ALTER TABLE users ADD COLUMN kycSubmittedAt DATETIME NULL');
      console.log('[DB] Added kycSubmittedAt column to users');
    }
    if (!userColumnNames.includes('kycRejectionReason')) {
      await query('ALTER TABLE users ADD COLUMN kycRejectionReason VARCHAR(255) NULL');
      console.log('[DB] Added kycRejectionReason column to users');
    }
    if (!userColumnNames.includes('referralCode')) {
      await query('ALTER TABLE users ADD COLUMN referralCode VARCHAR(50) NULL UNIQUE');
      console.log('[DB] Added referralCode column to users');
    }
    if (!userColumnNames.includes('referredBy')) {
      await query('ALTER TABLE users ADD COLUMN referredBy VARCHAR(191) NULL');
      console.log('[DB] Added referredBy column to users');
    }

    // Populate missing referral codes for existing users
    const unreferencedUsers = await query('SELECT id FROM users WHERE referralCode IS NULL OR referralCode = ""');
    if (unreferencedUsers.length > 0) {
      console.log(`[DB] Generating unique referral codes for ${unreferencedUsers.length} existing users...`);
      const { generateUniqueReferralCode } = require('./helpers/referral-code');
      for (const u of unreferencedUsers) {
        const code = await generateUniqueReferralCode();
        await query('UPDATE users SET referralCode = ? WHERE id = ?', [code, u.id]);
      }
      console.log('[DB] Existing users referral codes populated.');
    }

    // Safe Backfill Migration: Auto-link existing referred users into referrals table
    try {
      const backfillResult = await query(`
        INSERT IGNORE INTO referrals (id, referrerId, referredId, level, commissionEarned, status, createdAt, updatedAt)
        SELECT UUID(), parent.id, child.id, 1, 0.0, 'active', child.createdAt, UTC_TIMESTAMP()
        FROM users child
        JOIN users parent ON (child.referredBy = parent.id OR UPPER(child.referredBy) = UPPER(parent.referralCode))
        WHERE child.referredBy IS NOT NULL AND child.referredBy != '' AND child.id != parent.id
      `);
      if (backfillResult.affectedRows > 0) {
        console.log(`[DB Referral Backfill] Automatically linked ${backfillResult.affectedRows} existing referral relationships.`);
      }

      // Backfill missing deposit bonuses for existing referral completed deposits
      const { createReferralDepositBonuses } = require('./helpers/referral-bonus');
      const unbonusedTxs = await query(`
        SELECT t.id, t.userId, child.name AS depositorName, t.amount
        FROM transactions t
        JOIN users child ON child.id = t.userId
        LEFT JOIN referral_deposit_bonuses rdb ON rdb.depositTxId = t.id
        WHERE t.type = 'deposit' AND t.status = 'completed' AND rdb.id IS NULL
      `);
      for (const unb of unbonusedTxs) {
        await createReferralDepositBonuses(unb.userId, unb.depositorName, unb.amount, unb.id);
      }

      // Backfill missing trade bonuses for existing referral completed trades
      await query(`
        INSERT IGNORE INTO trade_bonuses (id, leaderId, traderId, traderName, traderEmail, assetSymbol, tradeAmount, bonusPercentage, bonusAmount, tradeDirection, tradeStatus, status, tradeId, createdAt, updatedAt)
        SELECT UUID(), parent.id, tr.userId, child.name, child.email, 'TRADE', tr.amount, 12, ROUND(tr.amount * 0.12, 2), tr.direction, IF(tr.profit > 0, 'won', 'lost'), 'pending', tr.id, tr.openedAt, UTC_TIMESTAMP()
        FROM trades tr
        JOIN users child ON child.id = tr.userId
        JOIN users parent ON (child.referredBy = parent.id OR UPPER(child.referredBy) = UPPER(parent.referralCode))
        WHERE tr.status != 'open' AND child.id != parent.id
      `);
    } catch (bfErr) {
      console.error('[DB Referral Backfill] Error:', bfErr.message);
    }
  } catch (err) {
    console.error('[DB] Auto-migrate error:', err.message);
  }
}

// Start server
const parsedPort = Number(port);
const priceEngine = require('./helpers/priceEngine');

const http = require('http');
const socketIO = require('socket.io');

const server = http.createServer(app);
const io = socketIO(server, {
  cors: corsOptions
});

app.set('io', io);

// Serve uploads directory
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

io.on('connection', (socket) => {
  console.log('[WS] New client connection:', socket.id);
  
  socket.on('join_room', (roomId) => {
    socket.join(roomId);
    console.log(`[WS] Socket ${socket.id} joined room ${roomId}`);
  });
  
  socket.on('join_admin', () => {
    socket.join('admin');
    console.log(`[WS] Socket ${socket.id} joined admin notification room`);
  });

  socket.on('admin_update_payout', (data) => {
    if (data?.symbol && data?.payout !== undefined && priceEngine.assets[data.symbol]) {
      const p = parseFloat(data.payout);
      if (!isNaN(p) && p > 0 && p <= 100) {
        priceEngine.assets[data.symbol].payout = p;
        if (priceEngine.adminSettings[data.symbol]) {
          priceEngine.adminSettings[data.symbol].payout = p;
        }
        io.emit('asset_payout_updated', { symbol: data.symbol, payout: p });
        console.log(`[WS Admin] Updated payout for ${data.symbol} to ${p}%`);
      }
    }
  });

  socket.on('admin_update_settings', (data) => {
    if (data?.symbol && data?.settings && priceEngine.adminSettings[data.symbol]) {
      Object.assign(priceEngine.adminSettings[data.symbol], data.settings);
      console.log(`[WS Admin] Updated price settings for ${data.symbol}`);
    }
  });

  socket.on('admin_set_price', (data) => {
    if (data?.symbol && data?.price !== undefined && priceEngine.adminSettings[data.symbol]) {
      priceEngine.adminSettings[data.symbol].manualPrice = parseFloat(data.price);
      console.log(`[WS Admin] Set manual price for ${data.symbol} to ${data.price}`);
    }
  });

  socket.on('admin_toggle_bot', async (data) => {
    const isEnabled = !!data?.enabled;
    priceEngine.setBotEnabled(isEnabled);
    try {
      await query(
        "INSERT INTO settings (id, `key`, value, updatedAt) VALUES (UUID(), 'smart_bot_enabled', ?, NOW(3)) ON DUPLICATE KEY UPDATE value = ?, updatedAt = NOW(3)",
        [isEnabled ? 'true' : 'false', isEnabled ? 'true' : 'false']
      );
    } catch (e) {
      console.error('[WS Admin] Failed to persist bot setting:', e.message);
    }
    io.emit('bot_status_changed', { enabled: isEnabled });
    console.log(`[WS Admin] Smart Bot toggled: ${isEnabled ? 'ON' : 'OFF'}`);
  });

  socket.on('bot_update', (data) => {
    if (data && typeof data === 'object') {
      priceEngine.setBotPayload(data);
    }
  });

  socket.on('disconnect', () => {
    console.log('[WS] Client disconnected:', socket.id);
  });
});

const { runAutoMigrations } = require('./utils/migrate-platform');
const { startDepositReconciliationSweep } = require('./controllers/paymentController');

if (!isNaN(parsedPort)) {
  // Bind to TCP Port (convert string to number, omit host parameter)
  server.listen(parsedPort, () => {
    console.log(`[Backend] Express server running on TCP Port: ${parsedPort}`);
    console.log(`[Backend] Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`[Backend] Node.js version: ${process.version}`);
    console.log(`[Backend] Database: MySQL (mysql2 driver)`);
    // FIX: runAutoMigrations() is async and creates the `candles` table.
    // It used to be fire-and-forget, so priceEngine.start() raced it and ran
    // SELECT COUNT(*) FROM candles before the table existed. That query threw,
    // was swallowed by the engine's try/catch, and seeding silently never ran,
    // leaving the market with no stored history at all.
    runAutoMigrations()
      .catch((e) => console.error('[Backend] Migration error:', e.message))
      .finally(() => {
        priceEngine.start(io);
        startDepositReconciliationSweep();
        const { autoProcessUnbonusedDeposits } = require('./helpers/referral-bonus');
        const { sweepPendingCryptoDeposits } = require('./helpers/crypto-deposit');
        setInterval(() => {
          autoProcessUnbonusedDeposits().catch(() => {});
          sweepPendingCryptoDeposits().catch(() => {});
        }, 10000);
        // Initial sweeps on startup
        autoProcessUnbonusedDeposits().catch(() => {});
        sweepPendingCryptoDeposits().catch(() => {});
      });
  }).on('error', (err) => {
    console.error(`[Backend] FATAL: Failed to start server on TCP port ${parsedPort}: ${err.message}`);
    process.exit(1);
  });
} else {
  // Bind to Unix Domain Socket / Named Pipe path (leave as string)
  server.listen(port, () => {
    console.log(`[Backend] Express server running on Unix Socket/Pipe: ${port}`);
    console.log(`[Backend] Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`[Backend] Node.js version: ${process.version}`);
    console.log(`[Backend] Database: MySQL (mysql2 driver)`);
    // FIX: runAutoMigrations() is async and creates the `candles` table.
    // It used to be fire-and-forget, so priceEngine.start() raced it and ran
    // SELECT COUNT(*) FROM candles before the table existed. That query threw,
    // was swallowed by the engine's try/catch, and seeding silently never ran,
    // leaving the market with no stored history at all.
    runAutoMigrations()
      .catch((e) => console.error('[Backend] Migration error:', e.message))
      .finally(() => {
        priceEngine.start(io);
        startDepositReconciliationSweep();
        const { autoProcessUnbonusedDeposits } = require('./helpers/referral-bonus');
        const { sweepPendingCryptoDeposits } = require('./helpers/crypto-deposit');
        setInterval(() => {
          autoProcessUnbonusedDeposits().catch(() => {});
          sweepPendingCryptoDeposits().catch(() => {});
        }, 10000);
        // Initial sweeps on startup
        autoProcessUnbonusedDeposits().catch(() => {});
        sweepPendingCryptoDeposits().catch(() => {});
      });
  }).on('error', (err) => {
    console.error(`[Backend] FATAL: Failed to start server on socket ${port}: ${err.message}`);
    process.exit(1);
  });
}

