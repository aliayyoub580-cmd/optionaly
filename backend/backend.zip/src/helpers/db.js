const path = require('path');
const mysql = require('mysql2/promise');
const fs = require('fs');

const rootEnv = path.join(__dirname, '..', '..', '..', '.env');
const backendEnv = path.join(__dirname, '..', '..', '.env');
if (fs.existsSync(rootEnv)) {
  require('dotenv').config({ path: rootEnv });
} else if (fs.existsSync(backendEnv)) {
  require('dotenv').config({ path: backendEnv });
}

const primaryUser = process.env.DB_USER !== undefined ? process.env.DB_USER : 'root';
const primaryPass = process.env.DB_PASS !== undefined ? process.env.DB_PASS.replace(/^["']|["']$/g, '') : '';
const localUser = process.env.LOCAL_DB_USER || 'root';
const localPass = process.env.LOCAL_DB_PASS !== undefined ? process.env.LOCAL_DB_PASS : '';

const dbHost = process.env.DB_HOST || '127.0.0.1';
const dbPort = parseInt(process.env.DB_PORT || '3306', 10);
const dbName = process.env.DB_NAME || 'u837914650_tradingweb';

let pool = null;
let isInitializing = null;

async function initPool() {
  if (pool) return pool;
  if (isInitializing) return isInitializing;

  isInitializing = (async () => {
    // Try primary pool
    const p1 = mysql.createPool({
      host: dbHost,
      port: dbPort,
      user: primaryUser,
      password: primaryPass,
      database: dbName,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      timezone: 'Z',
    });

    try {
      const conn = await p1.getConnection();
      conn.release();
      pool = p1;
      return pool;
    } catch (err) {
      console.log('[DB] Primary DB connection failed (' + err.message + '). Trying fallback local MySQL connection...');
      await p1.end().catch(() => {});
      
      const p2 = mysql.createPool({
        host: '127.0.0.1',
        port: dbPort,
        user: localUser,
        password: localPass,
        database: dbName,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0,
        timezone: 'Z',
      });

      try {
        const conn2 = await p2.getConnection();
        conn2.release();
        pool = p2;
        console.log('[DB] Connected to local MySQL successfully.');
        return pool;
      } catch (err2) {
        console.error('[DB] Fallback connection failed:', err2.message);
        await p2.end().catch(() => {});
        pool = null;
        throw new Error(`Database connection failed: Primary (${err.message}), Fallback (${err2.message})`);
      }
    }
  })();

  try {
    return await isInitializing;
  } catch (e) {
    isInitializing = null;
    throw e;
  }
}

// Pre-initialize pool
initPool().catch((err) => {
  console.error('[DB] Initial pool setup error:', err.message);
});

/**
 * Run a parameterised query, returning rows array.
 */
async function query(sql, params = []) {
  const activePool = await initPool();
  const [rows] = await activePool.execute(sql, params);
  return rows;
}

/**
 * Run multiple statements inside a single transaction.
 * cb receives a { query } object bound to the connection.
 */
async function transaction(cb) {
  const activePool = await initPool();
  const conn = await activePool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await cb({
      query: (sql, params = []) => conn.execute(sql, params).then(([r]) => r),
    });
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

module.exports = { query, transaction, getPool: initPool };
